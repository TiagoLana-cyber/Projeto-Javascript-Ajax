<?php  


if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // Recupera os dados do formulário  
    $nome = isset($_POST['nome']) ? $_POST['nome'] : '';  
    $apelido = isset($_POST['apelido']) ? $_POST['apelido'] : '';  
    $telemovel = isset($_POST['telemovel']) ? $_POST['telemovel'] : '';  
    $email = isset($_POST['email']) ? $_POST['email'] : '';  
    $tipoPagina = isset($_POST['tipoPagina']) ? $_POST['tipoPagina'] : '';  
    $prazo = isset($_POST['prazo']) ? $_POST['prazo'] : '';  

    // Mapeia os tipos de página e seus valores  
    $tiposDePagina = [  
        1000 => "Website Pessoal",  
        1500 => "E-commerce",  
        2000 => "Aplicativo Mobile",  
        2500 => "Sistema Personalizado"  
    ];  

    $tipoPaginaNome = isset($tiposDePagina[$tipoPagina]) ? $tiposDePagina[$tipoPagina] : 'Tipo Desconhecido';  

    // Captura os separadores  
    $separadoresSelecionados = isset($_POST['separadores']) ? $_POST['separadores'] : []; 

    // O total é calculado  
    $total = (int)$tipoPagina;  

     
    foreach ($separadoresSelecionados as $separador) {  
        $total += 400;  
    }  

   
    echo "<h1>Orçamento Recebido</h1>";  
    echo "<p><strong>Nome:</strong> $nome</p>";  
    echo "<p><strong>Apelido:</strong> $apelido</p>";  
    echo "<p><strong>Telemóvel:</strong> $telemovel</p>";  
    echo "<p><strong>Email:</strong> $email</p>";  
    echo "<p><strong>Tipo de Página:</strong> $tipoPaginaNome</p>"; // Exibe o nome da página  
    echo "<p><strong>Prazo:</strong> $prazo</p>";  

    // Exibe apenas os nomes dos separadores selecionados  
    $nomesSeparadores = implode(separator: ', ', array: $separadoresSelecionados);  
    echo "<p><strong>Separadores Selecionados:</strong> $nomesSeparadores</p>";  

    echo "<p><strong>Total:</strong> €" . number_format(num: $total, decimals: 2, decimal_separator: ',', thousands_separator: '.') . "</p>";  
} else {  
    echo "<p>Erro ao enviar o formulário. Por favor, tente novamente.</p>";  
}