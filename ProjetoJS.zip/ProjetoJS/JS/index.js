 
    $(document).ready(function() {  
        setTimeout(function() {  
            alert("Seja bem-vindo à LanaBrandys Information Solutions!");   
        }, 5000);  

        const rssUrl = "noticias.xml";

        function loadNews() {  
            $.ajax({  
                url: rssUrl,  
                type: 'GET',  
                dataType: 'xml',  
                success: function(data) {  
                    $(data).find("item").each(function() {  
                        const title = $(this).find("title").text();  
                        const link = $(this).find("link").text();  
                        const description = $(this).find("description").text();  

                        $('#news-list').append(`  
                            <li>  
                                <a href="${link}" target="_blank">${title}</a>  
                                <p>${description}</p>  
                            </li>  
                        `);  
                    });  
                },  
                error: function() {  
                    $('#news-list').append('<li>Erro ao carregar notícias.</li>');  
                }  
            });  
        }  

        // Carregar notícias apenas uma vez quando o botão for clicado pela primeira vez  
        let newsLoaded = false;  
        $('#toggle-news').click(function() {  
            if (!newsLoaded) {  
                loadNews();  
                newsLoaded = true;  
            }  
            $('#news-list').toggle();  
            const btnText = $('#news-list').is(':visible') ? 'Ocultar Notícias' : 'Mostrar Notícias';  
            $(this).text(btnText);  
        });  
    });  
