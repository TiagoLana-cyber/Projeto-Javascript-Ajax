document.getElementById("contactForm").addEventListener("submit", function (event) {
    event.preventDefault(); 

    const name = document.getElementById("name").value;
    const surname = document.getElementById("surname").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;
    const date = document.getElementById("date").value;
    const reason = document.getElementById("reason").value;

    if (name && surname && phone && email && date && reason) {
        alert("Formulário enviado com sucesso!");
         
    } else {
        alert("Por favor, preencha todos os campos.");
    }
});


               



 

