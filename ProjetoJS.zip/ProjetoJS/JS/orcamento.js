function validarNome() {  
    const nome = document.getElementById("nome").value;  
    const nomeError = document.getElementById("nomeError");  
    if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(nome) || nome.length < 3) {  
        nomeError.textContent = "O nome deve ter pelo menos 3 caracteres e conter apenas letras.";  
    } else {  
        nomeError.textContent = "";  
    }  
}  

function validarApelido() {  
    const apelido = document.getElementById("apelido").value;  
    const apelidoError = document.getElementById("apelidoError");  
    if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(apelido) || apelido.length < 3) {  
        apelidoError.textContent = "O apelido deve ter pelo menos 3 caracteres e conter apenas letras.";  
    } else {  
        apelidoError.textContent = "";  
    }  
}  

function validarTelemovel() {  
    const telemovel = document.getElementById("telemovel").value;  
    const telemovelError = document.getElementById("telemovelError");  
    if (!/^\d{9}$/.test(telemovel)) {  
        telemovelError.textContent = "O telemóvel deve conter 9 dígitos numéricos.";  
    } else {  
        telemovelError.textContent = "";  
    }  
}  

function validarEmail() {  
    const email = document.getElementById('email').value;  
    const erroEmail = document.getElementById('erroEmail');  
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;  

    if (!emailRegex.test(email)) {  
        erroEmail.textContent = "Campo inválido. Por favor, insira um email válido.";  
        erroEmail.classList.add("error");  
    } else {  
        erroEmail.textContent = "";  
        erroEmail.classList.remove("error");  
    }  
}  

function atualizarValor() {  
    const tipoPaginaSelect = document.getElementById("tipoPagina");  
    const valorPagina = document.getElementById("valorPagina");  
    valorPagina.value = tipoPaginaSelect.value; 
    calcularOrcamento();  
}  

function calcularOrcamento() {  
    const tipoPagina = parseFloat(document.getElementById("valorPagina").value);  
    const prazo = parseInt(document.getElementById("prazo").value) || 0;  
    const separadoresChecked = Array.from(document.querySelectorAll('input[type="checkbox"]:checked'));  
    
    // Captura os nomes dos separadores  
    const separadores = separadoresChecked.map(checkbox => checkbox.getAttribute("data-label"));   

    let total = tipoPagina + separadores.length * 400;  
    let desconto = Math.min(prazo * 0.05, 0.20) * total; 
    total -= desconto;  

    document.getElementById("total").innerText = `Orçamento Final: ${total.toFixed(2)}€`;  

    
    document.getElementById('separadores').value = separadores.join(', ');
}  